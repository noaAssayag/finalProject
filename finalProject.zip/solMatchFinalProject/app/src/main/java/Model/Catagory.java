package Model;

public enum Catagory {
    HOME_COOCKING,
    FARNICHAR,
    TOOLS,
    OTHER
}
