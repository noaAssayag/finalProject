package com.example.solmatch;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.time.Instant;
import java.time.LocalDate;

public class registerActivity extends AppCompatActivity {
    public static String keyUserName="userName";
    public static String keyEmail="email";

    private DatabaseReference mDatabase;

    TextView title;
    ImageView logo;
    EditText userName,email;
    CalendarView calendar;
    Button btContinue;

    String birthday;
    String userName_text;
    String email_text;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://solmatch-a1d9a-default-rtdb.firebaseio.com/");
        DatabaseReference myRef = database.getReference("Users");

        //widgets
        title=findViewById(R.id.laTilteReg);
        userName=findViewById(R.id.UserNameRegText);
        email=findViewById(R.id.EmailRegText);
        calendar=(CalendarView) findViewById(R.id.calendarReg);
        btContinue=(Button)findViewById(R.id.BtContinue) ;

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                birthday=(i1+1)+"/"+i2+"/"+i;
            }
        });

        btContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userName_text = userName.getText().toString();
                email_text = email.getText().toString();
                if (TextUtils.isEmpty(userName_text) || TextUtils.isEmpty(email_text) || TextUtils.isEmpty(birthday.toString())) {
                    Toast.makeText(registerActivity.this, "please fill the fields", Toast.LENGTH_SHORT).show();
                } else {
                    Intent i = new Intent(registerActivity.this, redisterAdd.class);
                    i.putExtra(keyUserName, userName_text);
                    i.putExtra(keyEmail, email_text);
                    startActivity(i);
                }
            }
        });



    }


}