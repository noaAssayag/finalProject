package com.example.solmatch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class redisterAdd extends AppCompatActivity {
    EditText password,rePassword;
    Button btReg;
    RadioButton radioButtonHost,radioButtonSoilder,radioButton;
    RadioGroup radioGroup;
    UserType type;
    String password_text, rePassword_text;

    String userEmail,userName;
    //Firebase
    FirebaseAuth auth;
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redister_add);

        password=findViewById(R.id.PasswordRegText);
        rePassword=findViewById(R.id.RePasswordRegText);
        radioButtonHost=findViewById(R.id.Rbhost);
        radioButtonSoilder=findViewById(R.id.Rbsoldier);
        btReg=(Button) findViewById(R.id.BtReg);
        radioGroup=findViewById(R.id.radioGroup);

         //FireBase Auth
        auth=FirebaseAuth.getInstance();



        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checked) {
                radioButton=findViewById(checked);
                if(radioButton.getId()==radioButtonHost.getId())
                {
                    type=UserType.host;
                }
                else{
                    type=UserType.soldier;
                }

            }
        });
        btReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                password_text=password.getText().toString();
                rePassword_text=rePassword.getText().toString();

                if(TextUtils.isEmpty(password_text)|| TextUtils.isEmpty(rePassword_text)||TextUtils.isEmpty(type.toString()))
                {
                    Toast.makeText(redisterAdd.this, "please fill the fields",Toast.LENGTH_SHORT).show();
                }
                else{
                    if((password.equals(rePassword)))
                    {
                        Bundle extras = getIntent().getExtras();
                        if (extras != null) {
                            userName=extras.getString(registerActivity.keyUserName);
                            userEmail=extras.getString(registerActivity.keyEmail);
                            RegisterNow(userName,userEmail,password_text);
                    }else {
                            Toast.makeText(redisterAdd.this, "The passwords do not match",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });


    }
    private void RegisterNow(final String userName,String email, String password){
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    FirebaseUser fireBaseUser=auth.getCurrentUser();
                    String userId=fireBaseUser.getUid();

                    ref= FirebaseDatabase.getInstance().getReference("User")
                            .child(userId);

                    HashMap<String, String> hashmap= new HashMap<>();
                    hashmap.put("id",userId);
                    hashmap.put("username", userName);

                    //opening the main activity after success registration
                    ref.setValue(hashmap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                Intent i= new Intent(redisterAdd.this,loginActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(i);
                                finish();
                            }
                            else{
                                Toast.makeText(redisterAdd.this,"invalid Email or Password", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                }
            }
        });

    }

}