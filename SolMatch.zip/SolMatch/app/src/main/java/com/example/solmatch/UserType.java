package com.example.solmatch;

public enum UserType {
    host,
    soldier,
    professional
}
